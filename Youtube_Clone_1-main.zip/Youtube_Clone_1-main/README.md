# Build and Deploy a Modern YouTube Clone Application in React JS with Material UI 5

![YouTube](https://i.ibb.co/4R5RkmW/Thumbnail-5.png)

## We will use this project for our Day4/16 video of Azure DevOps Zero to Hero series
